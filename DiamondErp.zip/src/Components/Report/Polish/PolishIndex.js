import React, { Component } from "react";
import Sidebar from "../../Common/Sidebar";

class PolishIndex extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
      <Sidebar>
        <div>Polishs</div>
      </Sidebar>
    );
  }
}

export default PolishIndex;
