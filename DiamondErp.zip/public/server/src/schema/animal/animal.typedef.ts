export interface AnimalModel{
    type: number
    count: number
}